﻿using System.Net;

namespace SistemaGeo.Models.Dtos
{
    public class ResponseApi
    {
        public string? Response { get; set; }
        public object? Object { get; set; }
        public HttpStatusCode? StatusCode { get; set; }
    }
}
