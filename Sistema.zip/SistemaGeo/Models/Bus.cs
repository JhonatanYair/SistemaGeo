﻿using System;
using System.Collections.Generic;

namespace SistemaGeo.Models;

public partial class Bus
{
    public int Id { get; set; }

    public string Placa { get; set; } = null!;

    public int Capacidad { get; set; }

    public int CuposDisponibles { get; set; }

    public bool EnServicio { get; set; }

    public virtual ICollection<Registroparqueo> Registroparqueos { get; set; } = new List<Registroparqueo>();
}
