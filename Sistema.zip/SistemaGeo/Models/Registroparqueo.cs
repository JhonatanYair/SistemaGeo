﻿using System;
using System.Collections.Generic;

namespace SistemaGeo.Models;

public partial class Registroparqueo
{
    public int Id { get; set; }

    public int? BusId { get; set; }

    public int? ParqueaderoId { get; set; }
    public bool UbicacionActual {  get; set; } = false;

    public DateTime? FechaIngreso { get; set; }

    public DateTime? FechaSalida { get; set; }

    public virtual Bus? Bus { get; set; }

    public virtual Parqueadero? Parqueadero { get; set; }
}
