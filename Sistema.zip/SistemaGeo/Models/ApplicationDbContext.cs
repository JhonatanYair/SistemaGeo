﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SistemaGeo.Models;

public partial class ApplicationDbContext : DbContext
{
    public ApplicationDbContext()
    {
    }

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Bus> Buses { get; set; }

    public virtual DbSet<Parqueadero> Parqueaderos { get; set; }

    public virtual DbSet<Registroparqueo> Registroparqueos { get; set; }

//    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
//        => optionsBuilder.UseNpgsql("Host=localhost;Port=5433;Database=transporte_intermunicipal;Username=sa;Password=enter123");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Bus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("bus_pkey");

            entity.ToTable("bus");

            entity.HasIndex(e => e.Placa, "bus_placa_key").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Capacidad).HasColumnName("capacidad");
            entity.Property(e => e.CuposDisponibles).HasColumnName("cupos_disponibles");
            entity.Property(e => e.EnServicio)
                .HasDefaultValue(true)
                .HasColumnName("en_servicio");
            entity.Property(e => e.Placa)
                .HasMaxLength(10)
                .HasColumnName("placa");
        });

        modelBuilder.Entity<Parqueadero>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("parqueadero_pkey");

            entity.ToTable("parqueadero");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CapacidadMaxima).HasColumnName("capacidad_maxima");
            entity.Property(e => e.Latitud).HasColumnName("latitud");
            entity.Property(e => e.Longitud).HasColumnName("longitud");
            entity.Property(e => e.Municipio)
                .HasMaxLength(50)
                .HasColumnName("municipio");
        });

        modelBuilder.Entity<Registroparqueo>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("registroparqueo_pkey");

            entity.ToTable("registroparqueo");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.BusId).HasColumnName("bus_id");
            entity.Property(e => e.FechaIngreso)
                .HasDefaultValueSql("now()")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("fecha_ingreso");
            entity.Property(e => e.FechaSalida)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("fecha_salida");
            entity.Property(e => e.UbicacionActual)
                .HasColumnName("ubicacion_actual");
            entity.Property(e => e.ParqueaderoId).HasColumnName("parqueadero_id");

            entity.HasOne(d => d.Bus).WithMany(p => p.Registroparqueos)
                .HasForeignKey(d => d.BusId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("fk_bus");

            entity.HasOne(d => d.Parqueadero).WithMany(p => p.Registroparqueos)
                .HasForeignKey(d => d.ParqueaderoId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("fk_parqueadero");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
