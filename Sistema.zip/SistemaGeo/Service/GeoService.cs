﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SistemaGeo.Models;
using SistemaGeo.Models.Dtos;
using System.Net;

namespace SistemaGeo.Service
{
    public interface IGeoService
    {
        Task<List<ParqueaderoDtos>> GetParqueaderos();
        Task<ParqueaderoDtos> GetInfoParqueadero(int idParqueadero);
        Task<ResponseApi> MoverBus(int idBus, int idDestino);
    }

    public class GeoService : IGeoService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GeoService(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<ParqueaderoDtos>> GetParqueaderos()
        {
            var parqueaderos = await _context.Parqueaderos.Include(p => p.Registroparqueos).ThenInclude(c => c.Bus).ToListAsync();
            var parqueaderoDto = _mapper.Map<List<ParqueaderoDtos>>(parqueaderos);

            foreach (var dto in parqueaderoDto)
            {
                dto.NumeroBusesParqueadero = _context.Registroparqueos
                    .Where(p => p.ParqueaderoId == dto.Id && p.UbicacionActual == true)
                    .Count();
            }
            return parqueaderoDto;
        }

        public async Task<ParqueaderoDtos> GetInfoParqueadero(int idParqueadero)
        {
            var parqueadero = await _context.Parqueaderos
                .Include(p => p.Registroparqueos)
                .FirstOrDefaultAsync(p => p.Id == idParqueadero);

            var parqueaderoDto = _mapper.Map<ParqueaderoDtos>(parqueadero);
            parqueaderoDto.NumeroBusesParqueadero = _context.Registroparqueos.Where(p => p.ParqueaderoId == idParqueadero && p.UbicacionActual == true).Count();
            return parqueaderoDto;
        }

        public async Task<ResponseApi> MoverBus(int idBus,int idDestino)
        {
            var infoBus = await _context.Buses.Include(p => p.Registroparqueos).FirstOrDefaultAsync(p => p.Id == idBus);
            var registroParqueadero = await _context.Registroparqueos.Where(p => p.BusId == idBus && p.UbicacionActual == true).ToListAsync();

            var parqueaderoDestino = _context.Parqueaderos.FirstOrDefault(p => p.Id == idDestino);
            var parqueaderoDestinoDto = _mapper.Map<ParqueaderoDtos>(parqueaderoDestino);
            parqueaderoDestinoDto.NumeroBusesParqueadero = _context.Registroparqueos.Where(p => p.ParqueaderoId == idDestino && p.UbicacionActual == true).Count();

            if (parqueaderoDestino.CapacidadMaxima == parqueaderoDestinoDto.NumeroBusesParqueadero)
            {               
                return new ResponseApi() 
                { Response = "Capacidad maxima alcanzada",StatusCode = HttpStatusCode.BadRequest };
            }

            foreach (var regis in registroParqueadero)
            {
                regis.UbicacionActual = false;  
                regis.FechaSalida = DateTime.Now;
            }

            var AddMover = new Registroparqueo()
            {
                BusId = idBus,
                ParqueaderoId = idDestino,
                UbicacionActual = true,
                FechaIngreso = DateTime.Now
            };

            await _context.Registroparqueos.AddAsync(AddMover);
            await _context.SaveChangesAsync();

            return new ResponseApi() { Object = AddMover, StatusCode = HttpStatusCode.OK};
        }

    }
}
