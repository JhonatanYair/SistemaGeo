

-- Tabla de Parqueaderos
CREATE TABLE parqueadero (
    id SERIAL PRIMARY KEY,
    municipio VARCHAR(50) NOT NULL,
    latitud FLOAT NOT NULL,
    longitud FLOAT NOT NULL,
    capacidad_maxima INT NOT NULL
);

-- Tabla de Buses
CREATE TABLE bus (
    id SERIAL PRIMARY KEY,
    placa VARCHAR(10) UNIQUE NOT NULL,
    capacidad INT NOT NULL,
    cupos_disponibles INT NOT NULL CHECK (cupos_disponibles >= 0),
    en_servicio BOOLEAN NOT NULL DEFAULT TRUE
);

-- Tabla de Registro de Parqueo
CREATE TABLE registroparqueo (
    id SERIAL PRIMARY KEY,
    bus_id INT,
    parqueadero_id INT,
    ubicacion_actual BOOLEAN DEFAULT false,
    fecha_ingreso TIMESTAMP DEFAULT NOW(),
    fecha_salida TIMESTAMP
);

-- 4. Agregar las restricciones de claves foráneas
ALTER TABLE registroparqueo
ADD CONSTRAINT fk_bus FOREIGN KEY (bus_id) REFERENCES bus(id) ON DELETE CASCADE;

ALTER TABLE registroparqueo
ADD CONSTRAINT fk_parqueadero FOREIGN KEY (parqueadero_id) REFERENCES parqueadero(id) ON DELETE CASCADE;

-- Inserción de datos en la tabla Parqueadero
INSERT INTO parqueadero (municipio, latitud, longitud, capacidad_maxima) VALUES
('Chocontá', 5.146678, -73.687044, 2),
('Tibiritá', 5.051490, -73.504577, 3),
('Jerusalén', 4.562677, -74.695855, 2),
('Ricaurte', 4.282114, -74.767717, 3),
('Puerto Salgar', 5.466157, -74.654130, 2),
('La Vega', 4.992574, -74.338211, 3),
('Útica', 5.185815, -74.481177, 2),
('Villeta', 5.013166, -74.470477, 4),
('Guasca', 4.869582, -73.874693, 3),
('Choachí', 4.526448, -73.924819, 2),
('Pacho', 5.140074, -74.159068, 2),
('Yacopí', 5.463235, -74.338550, 2),
('Cogua', 5.066298, -73.979012, 2),
('Cota', 4.807059, -74.109258, 3),
('Sopó', 4.913516, -73.941829, 4),
('Tocancipá', 4.967864, -73.905176, 4),
('Facatativá', 4.819769, -74.366498, 4),
('El Colegio', 4.582815, -74.443732, 2),
('Simijaca', 5.507497, -73.848055, 2),
('Ubaté', 5.310340, -73.819161, 3),
('Bogotá D.C.', 4.677584, -74.147794, 8);

-- Inserción de 59 Buses
INSERT INTO bus (placa, capacidad, cupos_disponibles) VALUES
('ABC123', 40, 35), ('DEF456', 30, 20), ('GHI789', 25, 10), 
('JKL012', 50, 45), ('MNO345', 20, 15), ('PQR678', 30, 30), 
('STU901', 40, 30), ('VWX234', 35, 25), ('YZA567', 25, 20), 
('BCD890', 50, 50), ('EFG123', 30, 25), ('HIJ456', 45, 35), 
('KLM789', 20, 15), ('NOP012', 40, 38), ('QRS345', 25, 22);
-- ('TUV678', 30, 30), ('WXY901', 50, 50), ('ZAB234', 20, 15), 
-- ('CDE567', 35, 30), ('FGH890', 30, 28), ('AAA111', 40, 35), 
-- ('BBB222', 30, 20), ('CCC333', 25, 10), ('DDD444', 50, 45), 
-- ('EEE555', 20, 15), ('FFF666', 30, 30), ('GGG777', 40, 30), 
-- ('HHH888', 35, 25), ('III999', 25, 20), ('JJJ000', 50, 50), 
-- ('KKK123', 30, 25), ('LLL456', 45, 35), ('MMM789', 20, 15), 
-- ('NNN012', 40, 38), ('OOO345', 25, 22), ('PPP678', 30, 30), 
-- ('QQQ901', 50, 50), ('RRR234', 20, 15), ('SSS567', 35, 30), 
-- ('TTT890', 30, 28), ('UUU111', 40, 35), ('VVV222', 30, 20), 
-- ('WWW333', 25, 10), ('XXX444', 50, 45), ('YYY555', 20, 15), 
-- ('ZZZ666', 30, 30), ('AAA777', 40, 30), ('BBB888', 35, 25), 
-- ('CCC999', 25, 20), ('DDD000', 50, 50), ('EEE123', 30, 25), 
-- ('FFF456', 45, 35), ('GGG789', 20, 15), ('HHH012', 40, 38), 
-- ('III345', 25, 22), ('JJJ678', 30, 30), ('KKK456', 50, 45), 
-- ('LLL789', 20, 15), ('MMM000', 30, 20), ('MMM001', 30, 11);

-- Inserción de 59 Buses en los Parqueaderos
INSERT INTO registroparqueo (bus_id, parqueadero_id, ubicacion_actual) VALUES
(1, 1, true), (2, 1, true), -- Chocontá (2 buses)
(3, 2, true), (4, 2, true), (5, 2, true), -- Tibiritá (3 buses)
(6, 3, true), (7, 3, true), -- Jerusalén (2 buses)
(8, 4, true), (9, 4, true), (10, 4, true), -- Ricaurte (3 buses)
(11, 5, true), (12, 5, true), -- Puerto Salgar (2 buses)
(13, 6, true), (14, 6, true), (15, 6, true); -- La Vega (3 buses)
-- (16, 7), (17, 7), -- Útica (2 buses)
-- (18, 8), (19, 8), (20, 8), (21, 8), -- Villeta (4 buses)
-- (22, 9), (23, 9), (24, 9), -- Guasca (3 buses)
-- (25, 10), (26, 10), -- Choachí (2 buses)
-- (27, 11), (28, 11), -- Pacho (2 buses)
-- (29, 12), (30, 12), -- Yacopí (2 buses)
-- (31, 13), (32, 13), -- Cogua (2 buses)
-- (33, 14), (34, 14), (35, 14), -- Cota (3 buses)
-- (36, 15), (37, 15), (38, 15), (39, 15), -- Sopó (4 buses)
-- (40, 16), (41, 16), (42, 16), (43, 16), -- Tocancipá (4 buses)
-- (44, 17), (45, 17), (46, 17), (47, 17), -- Facatativá (4 buses)
-- (48, 18), (49, 18), -- El Colegio (2 buses)
-- (50, 19), (51, 19), -- Simijaca (2 buses)
-- (52, 20), (53, 20), (54, 20), -- Ubaté (3 buses)
-- (55, 21), (56, 21), (57, 21), (58, 21), (59, 21),(60, 21); -- Bogotá D.C. (8 buses)