﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SistemaGeo.Models;
using SistemaGeo.Models.Dtos;
using System.Net;

namespace SistemaGeo.Service
{
    public interface IGeoService
    {
        Task<List<ParqueaderoDtos>> GetParqueaderos();
        Task<ParqueaderoDtos> GetInfoParqueadero(int idParqueadero);
        Task<ResponseApi> MoverBus(int idBus, int idDestino);
        Task<ResponseApi> LlegoBus(int idBus);
    }

    public class GeoService : IGeoService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GeoService(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<ParqueaderoDtos>> GetParqueaderos()
        {
            var parqueaderos = await _context.Parqueaderos.Include(p => p.Registroparqueos).ThenInclude(c => c.Bus).ToListAsync();
            var parqueaderoDto = _mapper.Map<List<ParqueaderoDtos>>(parqueaderos);

            foreach (var dto in parqueaderoDto)
            {
                dto.NumeroBusesParqueadero = _context.Registroparqueos
                    .Where(p => p.ParqueaderoId == dto.Id && p.UbicacionActual == true)
                    .Count();
            }
            return parqueaderoDto;
        }

        public async Task<ParqueaderoDtos> GetInfoParqueadero(int idParqueadero)
        {
            var parqueadero = await _context.Parqueaderos
                .Include(p => p.Registroparqueos)
                .FirstOrDefaultAsync(p => p.Id == idParqueadero);

            var parqueaderoDto = _mapper.Map<ParqueaderoDtos>(parqueadero);
            parqueaderoDto.NumeroBusesParqueadero = _context.Registroparqueos.Where(p => p.ParqueaderoId == idParqueadero && p.UbicacionActual == true).Count();
            return parqueaderoDto;
        }

        public async Task<ResponseApi> MoverBus(int idBus,int idDestino)
        {
            var infoBus = await _context.Buses.Include(p => p.Registroparqueos).FirstOrDefaultAsync(p => p.Id == idBus);
            var registroParqueadero = await _context.Registroparqueos.Where(p => p.BusId == idBus && p.UbicacionActual == true).Include(p => p.Parqueadero).ToListAsync();

            var parqueaderoDestino = _context.Parqueaderos.FirstOrDefault(p => p.Id == idDestino);
            var parqueaderoDestinoDto = _mapper.Map<ParqueaderoDtos>(parqueaderoDestino);
            parqueaderoDestinoDto.NumeroBusesParqueadero = _context.Registroparqueos.Where(p => p.ParqueaderoId == idDestino && p.UbicacionActual == true).Count();

            double long1 = 0;
            double lat1 = 0;
            double long2 = parqueaderoDestino.Longitud;
            double lat2 = parqueaderoDestino.Latitud;

            if (parqueaderoDestino.CapacidadMaxima == parqueaderoDestinoDto.NumeroBusesParqueadero)
            {               
                return new ResponseApi() 
                { Response = "Capacidad maxima alcanzada",StatusCode = HttpStatusCode.BadRequest };
            }

            foreach (var regis in registroParqueadero)
            {
                lat1 = regis.Parqueadero.Latitud;
                long1 = regis.Parqueadero.Longitud;

                regis.UbicacionActual = false;  
                regis.FechaSalida = DateTime.Now;
            }

            double distanciaKm = CalcularDistancia(lat1,long1,lat2,long2);
            double tiempo = distanciaKm / 60;

            var AddMover = new Registroparqueo()
            {
                BusId = idBus,
                ParqueaderoId = idDestino,
                UbicacionActual = true,
                FechaIngreso = DateTime.Now,
                DistanciaKm = distanciaKm,
                TiempoViaje = tiempo
            };

            await _context.Registroparqueos.AddAsync(AddMover);
            await _context.SaveChangesAsync();

            return new ResponseApi() { Object = AddMover, StatusCode = HttpStatusCode.OK};
        }

        public async Task<ResponseApi> LlegoBus(int idBus)
        {

            var registroParqueadero = _context.Registroparqueos.FirstOrDefault(p => p.BusId == idBus && p.UbicacionActual == true);

            registroParqueadero.EstadoViaje = "En parqueadero";
            registroParqueadero.TiempoViaje = 100;

            await _context.SaveChangesAsync();

            return new ResponseApi() { Object = registroParqueadero, StatusCode = HttpStatusCode.OK };
        }

        public double CalcularDistancia(double lat1, double lon1, double lat2, double lon2)
        {
            const double R = 6371; // Radio de la Tierra en km
            double dLat = GradosARadianes(lat2 - lat1);
            double dLon = GradosARadianes(lon2 - lon1);

            double a =
                Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(GradosARadianes(lat1)) * Math.Cos(GradosARadianes(lat2)) *
                Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            double distancia = R * c; // Distancia en km

            return distancia;
        }

        private double GradosARadianes(double grados)
        {
            return grados * (Math.PI / 180);
        }

    }
}
