﻿using Microsoft.AspNetCore.Mvc;
using SistemaGeo.Models;
using SistemaGeo.Models.Dtos;
using SistemaGeo.Service;
using System.Net;

namespace SistemaGeo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GeoController : ControllerBase
    {
        private readonly IGeoService _geoService;

        public GeoController(IGeoService geoService) 
        {
            _geoService = geoService;
        }

        [HttpGet("/GetParqueaderos")]
        public async Task<IActionResult> GetParqueaderos()
        {
            return Ok( await _geoService.GetParqueaderos());
        }

        [HttpGet("/GetInfoParqueadero")]
        public async Task<IActionResult> GetInfoParqueadero(int idParqueadero)
        {
            return Ok(await _geoService.GetInfoParqueadero(idParqueadero));
        }

        [HttpPost("/MoverBus")]
        public async Task<IActionResult> MoverBus([FromBody] MoverBusDto moverBusDto)
        {
            var response = await _geoService.MoverBus(moverBusDto.idBus, (int)moverBusDto.idDestino);

            if(response.StatusCode == HttpStatusCode.OK)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }

        }

        [HttpPost("/LlegoBus")]
        public async Task<IActionResult> LlegoBus([FromBody] MoverBusDto dto)
        {
            var response = await _geoService.LlegoBus(dto.idBus);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

    }
}
