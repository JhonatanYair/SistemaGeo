﻿using System;
using System.Collections.Generic;

namespace SistemaGeo.Models;

public partial class Parqueadero
{
    public int Id { get; set; }

    public string Municipio { get; set; } = null!;

    public double Latitud { get; set; }

    public double Longitud { get; set; }

    public int CapacidadMaxima { get; set; }

    public virtual ICollection<Registroparqueo> Registroparqueos { get; set; } = new List<Registroparqueo>();
}
