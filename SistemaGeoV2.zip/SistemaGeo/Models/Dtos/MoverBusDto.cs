﻿namespace SistemaGeo.Models.Dtos
{
    public class MoverBusDto
    {
        public int idBus { get; set; }
        public int? idDestino { get; set; }
    }
}
