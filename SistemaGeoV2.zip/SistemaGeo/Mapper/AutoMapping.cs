﻿using AutoMapper;
using SistemaGeo.Models;
using SistemaGeo.Models.Dtos;

namespace SistemaGeo.Mapper
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            CreateMap<ParqueaderoDtos, Parqueadero>();
            CreateMap<Parqueadero, ParqueaderoDtos>();
        }
    }
}
