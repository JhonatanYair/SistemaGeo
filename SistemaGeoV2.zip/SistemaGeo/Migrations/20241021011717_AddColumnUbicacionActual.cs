﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace SistemaGeo.Migrations
{
    /// <inheritdoc />
    public partial class AddColumnUbicacionActual : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "bus",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    placa = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    capacidad = table.Column<int>(type: "integer", nullable: false),
                    cupos_disponibles = table.Column<int>(type: "integer", nullable: false),
                    en_servicio = table.Column<bool>(type: "boolean", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("bus_pkey", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "parqueadero",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    municipio = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    latitud = table.Column<double>(type: "double precision", nullable: false),
                    longitud = table.Column<double>(type: "double precision", nullable: false),
                    capacidad_maxima = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("parqueadero_pkey", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "registroparqueo",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    bus_id = table.Column<int>(type: "integer", nullable: true),
                    parqueadero_id = table.Column<int>(type: "integer", nullable: true),
                    UbicacionActual = table.Column<bool>(type: "boolean", nullable: false,defaultValue: false),
                    fecha_ingreso = table.Column<DateTime>(type: "timestamp without time zone", nullable: true, defaultValueSql: "now()"),
                    fecha_salida = table.Column<DateTime>(type: "timestamp without time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("registroparqueo_pkey", x => x.id);
                    table.ForeignKey(
                        name: "fk_bus",
                        column: x => x.bus_id,
                        principalTable: "bus",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_parqueadero",
                        column: x => x.parqueadero_id,
                        principalTable: "parqueadero",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "bus_placa_key",
                table: "bus",
                column: "placa",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_registroparqueo_bus_id",
                table: "registroparqueo",
                column: "bus_id");

            migrationBuilder.CreateIndex(
                name: "IX_registroparqueo_parqueadero_id",
                table: "registroparqueo",
                column: "parqueadero_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "registroparqueo");

            migrationBuilder.DropTable(
                name: "bus");

            migrationBuilder.DropTable(
                name: "parqueadero");
        }
    }
}
